package me.earth.phobos.event.events;

import me.earth.phobos.event.EventStage;

public class UpdateWalkingPlayerEvent extends EventStage {

    public UpdateWalkingPlayerEvent(int stage) {
        super(stage);
    }
}
