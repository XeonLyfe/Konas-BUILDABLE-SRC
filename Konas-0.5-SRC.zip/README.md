A leak of Phobos 1.3.3. 

*probably* not a token logger

a good base if you want to skid off a client because phobos crystalaura is good and is compatible with almost anything and later versions of phobos are known to not be very compatible with other mods due to mixins (although the code is somewhat scuffed, see mixinblock omg)
